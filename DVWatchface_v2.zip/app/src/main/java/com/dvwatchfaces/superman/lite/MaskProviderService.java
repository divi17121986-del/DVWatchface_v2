package com.dvwatchfaces.superman.lite;

import android.os.RemoteException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.wear.watchface.complications.data.ComplicationData;
import androidx.wear.watchface.complications.data.ComplicationType;
import androidx.wear.watchface.complications.data.PlainComplicationText;
import androidx.wear.watchface.complications.data.RangedValueComplicationData;
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceService;
import androidx.wear.watchface.complications.datasource.ComplicationRequest;

/**
 * Шаг 1 (тест связки): отдаёт ФИКСИРОВАННУЮ маску.
 * Бит k = 1 -> день недели k (Пн=0 ... Вс=6) красим красным.
 * TEST_MASK = 5 = 0b0000101 -> Пн и Ср красные (чтобы было видно, что провайдер работает).
 */
public class MaskProviderService extends ComplicationDataSourceService {

    private static final int TEST_MASK = 5;

    @Nullable
    @Override
    public ComplicationData getPreviewData(@NonNull ComplicationType type) {
        return build(TEST_MASK);
    }

    @Override
    public void onComplicationRequest(@NonNull ComplicationRequest request,
                                      @NonNull ComplicationRequestListener listener) {
        try {
            listener.onComplicationData(build(TEST_MASK));
        } catch (RemoteException ignored) {
        }
    }

    private static ComplicationData build(int mask) {
        return new RangedValueComplicationData.Builder(
                (float) mask, 0f, 127f,
                new PlainComplicationText.Builder("Маска выходных").build())
                .setText(new PlainComplicationText.Builder(String.valueOf(mask)).build())
                .build();
    }
}
